<?php
/**
 * Festival Wire CPT and related functionality.
 * Main hub file including modularized components and asset enqueuing.
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Define path to the current directory for includes
define( 'FESTIVAL_WIRE_INCLUDE_DIR', get_stylesheet_directory() . '/inc/festival-wire/' );

// Include modularized files
require_once FESTIVAL_WIRE_INCLUDE_DIR . 'festival-wire-post-type.php';
require_once FESTIVAL_WIRE_INCLUDE_DIR . 'festival-wire-ajax.php';
require_once FESTIVAL_WIRE_INCLUDE_DIR . 'festival-wire-query-filters.php';

/**
 * Enqueue scripts and styles for Festival Wire pages.
 * Kept in the main file as requested.
 */
function enqueue_festival_wire_assets() {
	global $wp_query; // Make sure global $wp_query is available

	// Only enqueue on festival_wire CPT archive pages.
	if ( is_post_type_archive( 'festival_wire' ) ) {

		// Enqueue badge colors CSS first
		$badge_colors_path = get_stylesheet_directory() . '/css/badge-colors.css';
		if ( file_exists( $badge_colors_path ) ) {
			wp_enqueue_style(
				'badge-colors',
				get_stylesheet_directory_uri() . '/css/badge-colors.css',
				array(),
				filemtime( $badge_colors_path )
			);
		}

		// Enqueue CSS
		$css_file_path = get_stylesheet_directory() . '/css/festival-wire.css';
		$css_file_uri  = get_stylesheet_directory_uri() . '/css/festival-wire.css';
		if ( file_exists( $css_file_path ) ) {
			wp_enqueue_style(
				'extrachill-festival-wire',
				$css_file_uri,
				array( 'badge-colors' ), // Make it dependent on badge-colors
				filemtime( $css_file_path )
			);
		}

		// Enqueue JS
		$js_file_path = get_stylesheet_directory() . '/js/festival-wire.js';
		$js_file_uri  = get_stylesheet_directory_uri() . '/js/festival-wire.js';
		if ( file_exists( $js_file_path ) ) {
			wp_enqueue_script(
				'extrachill-festival-wire',
				$js_file_uri,
				array( 'jquery' ), // Add dependencies if any
				filemtime( $js_file_path ),
				true // Load in footer
			);

			// Prepare data for localization
			// Note: Ensure $wp_query is the main query for the archive page here.
			$localize_params = array(
				'ajaxurl'         => admin_url( 'admin-ajax.php' ),
				'tip_nonce'       => wp_create_nonce( 'festival_wire_tip_nonce' ), // Nonce for the tip form
				'load_more_nonce' => wp_create_nonce( 'festival_wire_load_more_nonce' ), // Nonce for load more
				'query_vars'      => json_encode( $wp_query->query_vars ), // Pass current query variables
				'max_pages'       => $wp_query->max_num_pages // Pass max pages
			);

			// Add localized script data for AJAX
			wp_localize_script(
				'extrachill-festival-wire',
				'festivalWireParams',
				$localize_params
			);
		}
	} elseif ( is_singular( 'festival_wire' ) ) {
		// Enqueue badge colors CSS first
		$badge_colors_path = get_stylesheet_directory() . '/css/badge-colors.css';
		if ( file_exists( $badge_colors_path ) ) {
			wp_enqueue_style(
				'badge-colors',
				get_stylesheet_directory_uri() . '/css/badge-colors.css',
				array(),
				filemtime( $badge_colors_path )
			);
		}
		
		// Enqueue CSS on single pages
		$css_file_path = get_stylesheet_directory() . '/css/festival-wire.css';
		$css_file_uri  = get_stylesheet_directory_uri() . '/css/festival-wire.css';
		if ( file_exists( $css_file_path ) ) {
			wp_enqueue_style(
				'extrachill-festival-wire',
				$css_file_uri,
				array( 'badge-colors' ), // Make it dependent on badge-colors
				filemtime( $css_file_path )
			);
		}
		// Enqueue JS on single pages
		$js_file_path = get_stylesheet_directory() . '/js/festival-wire.js';
		$js_file_uri  = get_stylesheet_directory_uri() . '/js/festival-wire.js';
		if ( file_exists( $js_file_path ) ) {
			wp_enqueue_script(
				'extrachill-festival-wire',
				$js_file_uri,
				array( 'jquery' ),
				filemtime( $js_file_path ),
				true
			);

			// Localize script for AJAX
			$localize_params = array(
				'ajaxurl'   => admin_url( 'admin-ajax.php' ),
				'tip_nonce' => wp_create_nonce( 'festival_wire_tip_nonce' ),
			);
			wp_localize_script(
				'extrachill-festival-wire',
				'festivalWireParams',
				$localize_params
			);
		}
	}
}
add_action( 'wp_enqueue_scripts', 'enqueue_festival_wire_assets' );

// --- Festival Wire Tag to Festival Migration Tool (One-Time Admin Button) ---
add_action('admin_menu', function() {
	add_management_page(
		'Festival Wire Migration',
		'Festival Wire Migration',
		'manage_options',
		'festival-wire-migration',
		'festival_wire_migration_admin_page'
	);
});

function festival_wire_migration_admin_page() {
	if (!current_user_can('manage_options')) {
		wp_die('You do not have sufficient permissions to access this page.');
	}
	$done = get_option('festival_wire_migration_done');
	if ($done) {
		echo '<div class="notice notice-success"><p><strong>Migration already completed.</strong></p></div>';
		return;
	}
	if (isset($_POST['festival_wire_migrate']) && check_admin_referer('festival_wire_migrate_action')) {
		$report = festival_wire_perform_tag_to_festival_migration();
		update_option('festival_wire_migration_done', 1);
		echo '<div class="notice notice-success"><p><strong>Migration complete!</strong></p>';
		if (!empty($report)) {
			echo '<ul>';
			foreach ($report as $line) {
				echo '<li>' . esc_html($line) . '</li>';
			}
			echo '</ul>';
		}
		echo '</div>';
		return;
	}
	?>
	<div class="wrap">
		<h1>Festival Wire Tag to Festival Migration</h1>
		<p>This will migrate all tags currently attached to any Festival Wire post to the new <strong>festival</strong> taxonomy. The tags will be removed from all posts and deleted if unused. This action is one-time and cannot be undone.</p>
		<form method="post">
			<?php wp_nonce_field('festival_wire_migrate_action'); ?>
			<input type="submit" name="festival_wire_migrate" class="button button-primary" value="Migrate Festival Wire Tags to Festivals" onclick="return confirm('Are you sure? This cannot be undone.');">
		</form>
	</div>
	<?php
}

function festival_wire_perform_tag_to_festival_migration() {
	global $wpdb;
	$report = array();
	// 1. Get all tag IDs attached to any festival_wire post
	$tag_ids = $wpdb->get_col("
		SELECT DISTINCT tr.term_taxonomy_id
		FROM {$wpdb->term_relationships} tr
		JOIN {$wpdb->term_taxonomy} tt ON tr.term_taxonomy_id = tt.term_taxonomy_id
		JOIN {$wpdb->posts} p ON tr.object_id = p.ID
		WHERE p.post_type = 'festival_wire' AND tt.taxonomy = 'post_tag'
	");
	if (empty($tag_ids)) {
		$report[] = 'No tags found attached to festival_wire posts.';
		return $report;
	}
	foreach ($tag_ids as $tt_id) {
		$tag = $wpdb->get_row($wpdb->prepare(
			"SELECT t.term_id, t.name, t.slug FROM {$wpdb->terms} t JOIN {$wpdb->term_taxonomy} tt ON t.term_id = tt.term_id WHERE tt.term_taxonomy_id = %d",
			$tt_id
		));
		if (!$tag) continue;
		// Create festival term if not exists
		$festival_term = term_exists($tag->slug, 'festival');
		if (!$festival_term) {
			$festival_term = wp_insert_term($tag->name, 'festival', array('slug' => $tag->slug));
		}
		$festival_term_id = is_array($festival_term) ? $festival_term['term_id'] : $festival_term;
		// Get all posts (any type) with this tag
		$post_ids = $wpdb->get_col($wpdb->prepare(
			"SELECT tr.object_id FROM {$wpdb->term_relationships} tr WHERE tr.term_taxonomy_id = %d",
			$tt_id
		));
		if (empty($post_ids)) continue;
		// Attach festival term to all these posts
		foreach ($post_ids as $post_id) {
			wp_set_object_terms($post_id, intval($festival_term_id), 'festival', true);
			wp_remove_object_terms($post_id, intval($tag->term_id), 'post_tag');
		}
		// Optionally, delete tag if no longer used
		$count = (int) $wpdb->get_var($wpdb->prepare(
			"SELECT COUNT(*) FROM {$wpdb->term_relationships} WHERE term_taxonomy_id = %d",
			$tt_id
		));
		if ($count === 0) {
			wp_delete_term($tag->term_id, 'post_tag');
			$report[] = sprintf('Migrated and deleted tag "%s" (slug: %s).', $tag->name, $tag->slug);
		} else {
			$report[] = sprintf('Migrated tag "%s" (slug: %s), but it is still used elsewhere.', $tag->name, $tag->slug);
		}
	}
	return $report;
}
// --- End Migration Tool ---

// ... existing code ... 
// The following functions and their hooks have been moved to separate files:
// register_festival_wire_cpt() -> festival-wire-post-type.php
// add_location_to_festival_wire() -> festival-wire-post-type.php
// festival_wire_load_more_handler() -> festival-wire-ajax.php
// process_festival_wire_tip_submission() -> festival-wire-ajax.php
// verify_turnstile_response() -> festival-wire-ajax.php
// festival_wire_add_query_vars() -> festival-wire-query-filters.php
// festival_wire_modify_query() -> festival-wire-query-filters.php

